instA(Itsh, Ich, Ieh, _, Ics, Ies, Itipos) -->
		id(X),
		{buscar(Itsh,X,Iddir,Idtipo)},
		[:=],
		expComp(Itsh,Ieh,ECtipo,ECes,ECcs),
		{concatena(Ich,ECcs,Aux),
		 emite(Aux,ECes,[ECes, desapila-dir,Iddir], Ics, Ies),
		 comprueba(asignacion,Idtipo,ECtipo,Itipos)}.

instB(Itsh, Ich, Ieh, _, Ics, Ies, Itipos) -->
		id(X),
		{buscar(Itsh,X,Iddir,Idtipo)},
		[:=],
		{emite(Ich,Ieh,[Ieh, apila, Iddir], C1, ECeh)},
		expComp(Itsh,ECeh,ECtipo,ECes,ECcs),
		{concatena(C1,ECcs,C2),
		 emite(C2,ECes,[ECes, desapila-ind], Ics, Ies),
		 comprueba(asignacion,Idtipo,ECtipo,Itipos)}.
		 
		 
comprueba(asignacion, T, T, ok).
comprueba(asignacion, real, entero, ok).
comprueba(asignacion, entero, real, error).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, ECtipos, ECes, ECcs).
		
expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, E1tipos, E1es, E1cs),
		[<],
		expComp(ECtsh, E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, menor ], ECcs, ECes),
		comprueba(relacional,E1tipos,EC2tipos,ECtipos)}.
expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, E1tipos, E1es, E1cs),
		[>],
		expComp(ECtsh, E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, mayor ], ECcs, ECes),
		comprueba(relacional,E1tipos,EC2tipos,ECtipos)}.
expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, E1tipos, E1es, E1cs),
		[=],
		expComp(ECtsh, E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, igual ], ECcs, ECes),
		comprueba(igualdad,E1tipos,EC2tipos,ECtipos)}.	
		
		
exp(Etsh, Eeh, Etipos, Ees, Ecs) --> termino(Etsh, Eeh, Etipos, Ees, Ecs).

exp(Etsh, Eeh, Etipos, Ees, Ecs) -->
		termino(Etsh, Eeh, T1tipos, T1es, T1cs),
		[+],
		exp(Etsh, T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, suma], Ecs, Ees),
		comprueba(suma,T1tipos, E2tipos, Etipos)}. 
exp(Etsh, Eeh, Etipos, Ees, Ecs) -->
		termino(Etsh, Eeh, T1tipos, T1es, T1cs),
		[-],
		exp(Etsh, T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, resta], Ecs, Ees),
		comprueba(suma,T1tipos, E2tipos, Etipos)}. 
		
exp(Etsh, Eeh, Etipos, Ees, Ecs) -->
		termino(Etsh, Eeh, T1tipos, T1es, T1cs),
		[or],
		exp(Etsh, T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, or], Ecs, Ees),
		comprueba(and,T1tipos, E2tipos, Etipos)}. 
	
		
termino(Ttsh, Teh, Ttipos, Tes, Tcs)--> factor(Ttsh, Teh, Ttipos, Tes, Tcs).

termino(Ttsh, Teh, Ttipos, Tes, Tcs) -->
	factor(Ttsh, Teh, Ftipos, Fes, Fcs),
	[*],
	termino(Ttsh, Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,multiplica],Tcs,Tes),
	comprueba(suma,Ftipos,T2tipos,Ttipos)}.

termino(Ttsh, Teh, Ttipos, Tes, Tcs) -->
	factor(Ttsh, Teh, Ftipos, Fes, Fcs),
	[/],
	termino(Ttsh, Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,divide],Tcs,Tes),
	comprueba(division,Ftipos,T2tipos,Ttipos)}.
termino(Ttsh, Teh, Ttipos, Tes, Tcs) -->
	factor(Ttsh, Teh, Ftipos, Fes, Fcs),
	[and],
	termino(Ttsh, Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,and],Tcs,Tes),
	comprueba(and,Ftipos,T2tipos,Ttipos)}.	
	
factor(_, Feh, Ftipos, Fes, Fcs) -->
	simbolo(V, Ftipos),
	{emite([],Feh,[Feh, apila, V],Fcs, Fes)}.
	
factor(Ftsh, Feh, Idtipo, Fes, Fcs) --> 
		id(X), 
		{buscar(Ftsh, X, Iddir, Idtipo),
		emite([],Feh,[Feh, apila-dir, Iddir],Fcs,Fes)}. 

factor(Ftsh, Feh, ECtipos, ECes, ECcs) --> 
		['('], 
		expComp(Ftsh,Feh, ECtipos, ECes, ECcs), 
		[')']. 
	

id(X) --> 
		[X], {atom(X)}. 
		
simbolo(V, entero) --> 
		[V], {integer(V)}. 
		
simbolo(V, real) -->
		[V], {float(V)}. 

simbolo(true, bool) -->
		[true].

simbolo(false,bool) -->
		[false].
		
		
comprueba(_,error,_,error).
comprueba(_,_,error,error).

comprueba(relacional, entero, entero, bool) :- !.
comprueba(relacional, entero, real, bool) :- !.
comprueba(relacional, real, entero, bool) :- !.
comprueba(relacional, real, real, bool) :- !.

comprueba(igualdad, entero, entero, bool) :- !.
comprueba(igualdad, entero, real, bool) :- !.
comprueba(igualdad, real, entero, bool) :- !.
comprueba(igualdad, real, real, bool) :- !.
comprueba(igualdad, bool, bool, bool) :- !.

comprueba(suma, entero, entero, entero) :- !.
comprueba(suma, entero, real, real) :- !.
comprueba(suma, real, entero, real) :- !.
comprueba(suma, real, real, real) :- !.

comprueba(and, bool, bool, bool) :- !.

comprueba(division, entero, entero,real) :- !.
comprueba(division, entero, real, real) :- !.
comprueba(division, real, entero, real) :- !.
comprueba(division, real, real,real) :- !.

concatena(L1,L2,L3) :- append(L1,L2,L3).
emite(Ch,Eh,I,Cs,Es) :- append(Ch,[I],Cs), Es is Eh + 1.
 
buscar([[X, Idtipo, Iddir] | _], X, Iddir, Idtipo):-!. 

buscar([], _, -1, error):-!. 

buscar([_ | Resto], X, Iddir, Idtipo):- 
		buscar(Resto, X, Iddir, Idtipo). 
		
% Muestra una lista de listas
mostrar([]):- nl.
mostrar([A|As]) :- nl, muestra(A), mostrar(As).
% Muestra una lista.
muestra([]).
muestra([A|As]) :- write(A), write(' '), muestra(As).
