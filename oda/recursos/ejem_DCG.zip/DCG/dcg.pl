inst(Itsh, Ich, Ieh, Itipoh, Ics, Ies, Itipos) --> 
		id(X), 
		{buscar(Itsh, X, Iddir, Idtipo)}, 
		% Iddir e Idtipo los pongo a error si id no est� 
		[:=], 
		expComp(Itsh, Ieh, Etipo, Ees, Ecs), 
		{concatena(Ich,Ecs,Aux),
		 emite(Aux,Ees,[Ees,desapila-dir,Iddir],Ics,Ies),
		 comprobar_asig(Idtipo,Etipo,Itipos)}.
		


inst(Itsh, Ich, Ieh, Itipoh, Ics, Ies, Itipos) -->
		[while],
		expComp(Itsh, Ieh, Etipos, Ees, Ecs),
		[do],
		{ concatena(Ich,Ecs,Aux),
		  emite(Aux,Ees,[Ees,ir-falso,Ies],I2ch,I2eh),
		  %exigimos que la expresi�n del while sea booleana 
		  comprobar_condicion(Itipoh, Etipos, I2tipoh)
		},
		bloque(Itsh,I2ch, I2eh, I2tipoh, I2cs, I2es, Itipos),
		  %inst(Itsh,I2ch, I2eh, I2tipoh, I2cs, I2es, Itipos),
		{ emite(I2cs,I2es,[I2es, ir-a, Ieh], Ics,Ies)}.


bloque(Itsh,I2ch, I2eh, I2tipoh, I2cs, I2es, Itipos) -->
      [comienzo],
      instrucciones(Itsh,I2ch, I2eh, I2tipoh, I2cs, I2es, Itipos),
      [final].

instrucciones(Itsh,ISch, ISeh, IStipoh, IScs, ISes, IStipos) -->
	inst(Itsh,ISch, ISeh, IStipoh, Ics, Ies, Itipos),
	restoIns(Itsh,Ics, Ies, Itipos, IScs, ISes, RItipos),
	{comprobar(bloque,Itipos,RItipos,IStipos)}.
	
restoIns(Itsh,ISch, ISeh, IStipoh, ISch, ISeh, IStipoh) --> [;].

restoIns(Itsh,I2ch, I2eh, I2tipoh, I2cs, I2es, Itipos) -->
   [;],
   instrucciones(Itsh,I2ch, I2eh, I2tipoh, I2cs, I2es, Itipos).
      
		

inst(I1tsh, I1ch, I1eh, I1tipoh, I2cs, I2es, I2tipos) --> 
		[if], 
		expComp(I1tsh, I1eh, Etipos, Ees, Ecs), 
		[then], 
		{ concatena(I1ch, Ecs, Aux),
		  emite(Aux, Ees, [Ees, if-falso, I2es], I2ch, I2eh), 
		%exigimos que la expresi�n del if sea booleana 
		comprobar_condicion(I1tipoh, Etipos, I2tipoh)}, 
		inst(I1tsh, I2ch, I2eh, I2tipoh, I2cs, I2es, I2tipos). 

inst(_, Ich, Ieh, Itipoh, Ics, Ies, Itipoh) --> 
		[fin], {emite(Ich,Ieh,[Ieh,alto],Ics,Ies)}. 


expComp(ECtsh, ECeh, ECtipos, Yes, Ycs) -->
		exp(ECtsh, ECeh, Etipos, Ees, Ecs),
		yresto(ECtsh, Ees, Ytipos, Yes, Ecs, Ycs),
		{comprobar(relacional, Etipos, Ytipos, ECtipos)}.
		
yresto(Y1tsh, Y1eh, Y1tipos, Y2es, Y1ch, Y1cs) --> 
		[<], 
		exp(Y1tsh, Y1eh, Etipos, Ees, Ecs), 
		{concatena(Y1ch, Ecs, [[Ees, menor]], Y2ch), 
		Y2eh is Ees +1}, 
		yresto(Y1tsh, Y2eh, Y2tipos, Y2es, Y2ch, Y1cs), 
		{comprobar(relacional, Etipos, Y2tipos, Y1tipos)}. 

yresto(Y1tsh, Y1eh, Y1tipos, Y2es, Y1ch, Y1cs) --> 
		[>], 
		exp(Y1tsh, Y1eh, Etipos, Ees, Ecs), 
		{concatena(Y1ch, Ecs, [[Ees, mayor]], Y2ch), 
		Y2eh is Ees +1}, 
		yresto(Y1tsh, Y2eh, Y2tipos, Y2es, Y2ch, Y1cs), 
		{comprobar(relacional, Etipos, Y2tipos, Y1tipos)}. 

yresto(Y1tsh, Y1eh, Y1tipos, Y2es, Y1ch, Y1cs) --> 
		[=], 
		exp(Y1tsh, Y1eh, Etipos, Ees, Ecs), 
		{concatena(Y1ch, Ecs, [[Ees, igual]], Y2ch), 
		Y2eh is Ees +1}, 
		yresto(Y1tsh, Y2eh, Y2tipos, Y2es, Y2ch, Y1cs), 
		{comprobar(relacional, Etipos, Y2tipos, Y1tipos)}. 
				
yresto(_, Yeh, ok, Yeh, Yc, Yc) -->[]. 

exp(Etsh, Eeh, Etipos, Res, Rcs) --> 
		term(Etsh, Eeh, Ttipos, Tes, Tcs), 
		resto(Etsh, Tes, Rtipos, Res, Tcs, Rcs), 
		{comprobar(aditivo, Ttipos, Rtipos, Etipos)}. 

resto(R1tsh, R1eh, R1tipos, R2es, R1ch, R1cs) --> 
		[+], 
		term(R1tsh, R1eh, Ttipos, Tes, Tcs), 
		{concatena(R1ch, Tcs, [[Tes, suma]], R2ch), 
		R2eh is Tes +1},
		resto(R1tsh, R2eh, R2tipos, R2es, R2ch, R1cs), 
		{comprobar( aditivo, Ttipos, R2tipos, R1tipos)}. 

resto(R1tsh, R1eh, R1tipos, R2es, R1ch, R1cs) --> 
		[-], 
		term(R1tsh, R1eh, Ttipos, Tes, Tcs), 
		{concatena(R1ch, Tcs, [[Tes, resta]], R2ch), 
		R2eh is Tes +1}, 
		resto(R1tsh, R2eh, R2tipos, R2es, R2ch, R1cs), 
		{comprobar(aditivo, Ttipos, R2tipos, R1tipos)}. 

resto(_, Reh, ok, Reh, Rc, Rc) -->[]. 

term(Ttsh, Teh, Ttipos, Zes, Zcs) --> 
		fact(Ttsh, Teh, Ftipos, Fes, Fcs ), 
		zresto(Ttsh, Fes, Ztipos, Zes, Fcs, Zcs), 
		{comprobar(aditivo, Ftipos, Ztipos, Ttipos)}. 

zresto(Z1tsh, Z1eh, Z1tipos, Z2es, Z1ch, Z1cs) --> 
		[*], 
		fact(Z1tsh, Z1eh, Ftipos, Fes, Fcs), 
		{concatena(Z1ch, Fcs, [[Fes, multiplica]], Z2ch), 
		Z2eh is Fes +1}, 
		zresto(Z1tsh, Z2eh, Z2tipos, Z2es, Z2ch, Z1cs), 
		{comprobar(aditivo, Ftipos, Z2tipos, Z1tipos)}. 

zresto(Z1tsh, Z1eh, Z1tipos, Z2es, Z1ch, Z1cs) --> 
		[/], 
		fact(Z1tsh, Z1eh, Ftipos, Fes, Fcs), 
		{concatena(Z1ch, Fcs, [[Fes, divide]], Z2ch), 
		Z2eh is Fes +1}, 
		zresto(Z1tsh, Z2eh, Z2tipos, Z2es, Z2ch, Z1cs), 
		{comprobar(dividir, Ftipos, Z2tipos, Z1tipos)}. 
		
		

zresto(_, Reh, ok, Reh, Zc, Zc) --> []. 

fact(_, Feh, bool, Fes, [[Feh, apila, true]]) -->
		[true], {Fes is Feh +1}.
		
fact(_, Feh, bool, Fes, [[Feh, apila, false]]) -->
		[false], {Fes is Feh +1}.
		
fact(Ftsh, Feh, Idtipo, Fes, [[Feh, apila-dir, Iddir]]) --> 
		id(X), 
		{Fes is Feh +1, 
		buscar(Ftsh, X, Iddir, Idtipo)}. 
		
fact(_, Feh, Tipos, Fes, [[Feh, apila, V]]) --> 
		numero(V, Tipos),{Fes is Feh +1}. 
		

		
fact(Ftsh, Feh, Etipos, Ees, Ecs) --> 
		['('], 
		exp(Ftsh,Feh, Etipos, Ees, Ecs), 
		[')']. 


/*************** analizador l�xico y predicados auxiliares *********/ 
id(X) --> 
		[X], {atom(X)}. 
		
numero(V, entero) --> 
		[V], {integer(V)}. 
		
numero(V, real) -->
		[V], {float(V)}. 
		
buscar([[X, Iddir, Idtipo] | _], X, Iddir, Idtipo):-!. 

buscar([], _, -1, error):-!. 

buscar([_ | Resto], X, Iddir, Idtipo):- 
		buscar(Resto, X, Iddir, Idtipo). 
		
gen(C1, C2, C3, Cs, Eh, Es):- 
		append(C1, C2, C), append(C, C3, Cs), Es is Eh +1. 
concatena(X,Y,Z,R):- 
		append(X,Y,R1), append(R1,Z,R). 

% concatena
concatena(L1,L2,L3) :- append(L1,L2,L3).

emite(Ch,Eh,I,Cs,Es) :- append(Ch,[I],Cs), Es is Eh + 1.

% comprobar_asig(Idtipo, Etipo, Itipo) 
comprobar_asig(error, _, error):-!. 
comprobar_asig(_, error, error):-!. 
comprobar_asig(T, T, ok):-!. 
comprobar_asig(real, entero, ok):-!. 
comprobar_asig(entero, real, error):-!.

%comprobar_condicion(I1tipoh, Etipos, I2tipoh) 
comprobar_condicion(error, _, error):-!. 
comprobar_condicion(_, error, error):-!. 
comprobar_condicion(ok, bool, ok):-!. 
comprobar_condicion(ok, _, error):-!. 

%comprobar(aditivo, Ttipos, R2tipos, R1tipos) 

comprobar(_, error, _, error):-!. 
comprobar(_, _, error, error):-!.

comprobar(aditivo, entero, entero, entero):-!. 
comprobar(aditivo, entero, real, real):-!. 
comprobar(aditivo, real, entero, real):-!. 
comprobar(aditivo, real, real, real):-!. 

comprobar(relacional, bool, bool, bool):- !.
comprobar(relacional, entero, entero, bool):- !.
comprobar(relacional, entero, real, bool):- !.
comprobar(relacional, real, entero, bool):- !.
comprobar(relacional, real, real, bool):- !.


comprobar(dividir, _, _, real):-!. 

comprobar(_, Tipo, ok, Tipo):-!. 
comprobar(_,ok,Tipo,Tipo) :- !.
 

% Muestra una lista de listas
mostrar([]).
mostrar([A|As]) :- muestra(A), nl, mostrar(As).
% Muestra una lista.
muestra([]).
muestra([A|As]) :- write(A), write(' '), muestra(As).

% inst([[precio, 5, entero], [iva, 7, real]], [[1, codigoanterior]], 2, ok, C, E, T, [if, 2, +, precio, then, fin], []).

%inst([[precio, 5, entero], [iva, 7, real]], [[1, codigoanterior]], 2, ok,C, E,  T, [while, 2,+,precio , do, fin ], []). 

%inst([[precio, 5, entero], [iva, 7, real]], [[1, codigoanterior]], 2, ok, C, E,  T, [while, 2, +, precio, do,fin], []).

%ins([[precio, 5, entero], [iva, 7, real]], [[1, codigoanterior]], 2, C, E, ok, T, [iva, :=, precio, +, 2],[]).

% bloque([[precio, 5, entero], [iva, 7, real]],[[1,codigoanterior]],2,ok,C,E,T,[comienzo,if, 2, +, precio, then, fin, while, 2, +, precio, do,comienzo,fin,;,final,final],[]).

% bloque([[precio, 5, entero], [iva, 7, real]],[[1,codigoanterior]],2,ok,C,E,T,[comienzo,if, 2, +, precio, then, fin,;, while, 2, +, precio, do,comienzo,fin,;,final,;,final],[]), muestraCodigo(C).