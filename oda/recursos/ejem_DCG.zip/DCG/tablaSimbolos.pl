declaraciones(Ts) -->
	[var],
	lista(1, [[var, none, none],[finVar, none,noe], [begin, none, none], [end, none, none], [if, none, none], [while, none, none], [then, none, none], [do, none, none]], Ts),
	[finVar].

lista(Dirh, L1tsh, L2tss) -->
	listaIds(Lids),
	[:],
	tipo(Ttipo, Ttam),
	[;],
	{a�adir(Lids, Dirh, Ttam, Ttipo, L1tsh, Dirs, L2tsh)},
	lista(Dirs, L2tsh, L2tss).

lista(Dirh,Ltsh,Ltsh) --> [].

listaIds([ X | Ls]) -->
	id(X),
	[,],
	listaIds(Ls).

listaIds([X]) -->
	id(X).

tipo(real, 2) --> [real].
tipo(entero, 1) --> [entero].
tipo(bool,1) --> [bool].



% /**** A. l�xico y acciones sem�nticas auxiliares ****/

id(X) -->
	[X], {atom(X)}.

a�adir([], Dir, _, _, Ts, Dir, Ts).

a�adir([X | L], Dir, Size, Tipo, Ts, Rdirs, Rtss):-
	Rdir is Dir + Size,
	noExiste(X, Ts),
	a�adir(L, Rdir, Size, Tipo, [[X, Tipo, Dir] | Ts], Rdirs, Rtss).

noExiste(X,[[X , _ , _] |_]):-!,write(X), write(' ya se declar�'), fail.

noExiste(X, [_ | R]):-
	noExiste(X, R).

noExiste(_, []).


% Muestra una lista de listas
mostrar([]):- nl.
mostrar([A|As]) :- nl, muestra(A), mostrar(As).
% Muestra una lista.
muestra([]).
muestra([A|As]) :- write(A), write(' '), muestra(As).
