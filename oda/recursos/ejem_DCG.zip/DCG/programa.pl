programa(Ts,C) -->
  [begin],
  declaraciones(Ts),
  bloque(Ts,[],0,ok,C,_,ok),
  [end].


%% Tabla de s�mbolos.
declaraciones(Ts) -->
	[var],
	lista(1, [[var, none, none],[finVar, none,noe], [begin, none, none], [end, none, none], [if, none, none], [while, none, none], [then, none, none], [do, none, none]], Ts),
	[finVar].

lista(Dirh, L1tsh, L2tss) -->
	listaIds(Lids),
	[:],
	tipo(Ttipo, Ttam),
	[;],
	{a�adir(Lids, Dirh, Ttam, Ttipo, L1tsh, Dirs, L2tsh)},
	lista(Dirs, L2tsh, L2tss).

lista(_,Ltsh,Ltsh) --> [].

listaIds([ X | Ls]) -->
	id(X),
	[,],
	listaIds(Ls).

listaIds([X]) -->
	id(X).

tipo(real, 2) --> [real].
tipo(entero, 1) --> [entero].
tipo(bool,1) --> [bool].


%% Instrucciones

bloque(Itsh,Ich, Ieh, Itipoh, Ics, Ies, Itipos) -->
      ['{'],
      instrucciones(Itsh,Ich, Ieh, Itipoh, Ics, Ies, Itipos),
      ['}'].
   
      
inst(Itsh, Ich, Ieh, _, Ics, Ies, Itipos) -->
		id(X),
		{buscar(Itsh,X,Iddir,Idtipo)},
		[:=],
		{emite(Ich,Ieh,[Ieh, apila, Iddir], C1, ECeh)},
		expComp(Itsh,ECeh,ECtipos,ECes,ECcs),
		{concatena(C1,ECcs,C2),
		 emite(C2,ECes,[ECes, desapila-ind], Ics, Ies),
		 comprueba(asignacion,Idtipo,ECtipos,Itipos)}.
		 
inst(Itsh, Ich, Ieh, _, Ics, Ies, Itipos) -->
		[while],
		['('],
		expComp(Itsh,Ieh,ECtipos,ECes,ECcs),
		[')'],
		[do],
		{ ECtipos == bool,
		  concatena(Ich,ECcs,Aux),
		  emite(Aux,ECes,[ECes,ir-falso,Ies],I2ch,I2eh) },
		bloque(Itsh,I2ch,I2eh,_,I2cs,I2es,Itipos),
		{ emite(I2cs,I2es,[I2es,ir-siempre,Ieh],Ics,Ies)}.
		
inst(Itsh, Ich, Ieh, _, Ics, Ies, Itipos) -->
		[if],
		['('],
		expComp(Itsh,Ieh,ECtipos,ECes,ECcs),
		[')'],
		[then],
		{ ECtipos == bool,
		  concatena(Ich,ECcs,Aux),
		  emite(Aux,ECes,[ECes,ir-falso,Bes],I2ch,I2eh) },
		bloque(Itsh,I2ch,I2eh,_,Bcs,Bes,Btipos),
		[else],
		{emite(Bcs,Bes,[Bes, ir-siempre, Ies], I3ch, I3eh)},
		bloque(Itsh,I3ch,I3eh,Btipos,Ics,Ies,Itipos).
	

instrucciones(Itsh,ISch, ISeh, IStipoh, IScs, ISes, IStipos) -->
	inst(Itsh,ISch, ISeh, IStipoh, Ics, Ies, Itipos),
	restoIns(Itsh,Ics, Ies, Itipos, IScs, ISes, RItipos),
	{comprobar(bloque,Itipos,RItipos,IStipos)}.

	
restoIns(_,ISch, ISeh, IStipoh, ISch, ISeh, IStipoh) --> [;].

restoIns(Itsh,Ich, Ieh, Itipoh, Ics, Ies, Itipos) -->
   [;],
   instrucciones(Itsh,Ich, Ieh, Itipoh, Ics, Ies, Itipos).


%% Expresiones


expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, ECtipos, ECes, ECcs).
		
expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, E1tipos, E1es, E1cs),
		[<],
		expComp(ECtsh, E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, menor ], ECcs, ECes),
		comprueba(relacional,E1tipos,EC2tipos,ECtipos)}.
expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, E1tipos, E1es, E1cs),
		[>],
		expComp(ECtsh, E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, mayor ], ECcs, ECes),
		comprueba(relacional,E1tipos,EC2tipos,ECtipos)}.
expComp(ECtsh, ECeh, ECtipos, ECes, ECcs) -->
		exp(ECtsh, ECeh, E1tipos, E1es, E1cs),
		[=],
		expComp(ECtsh, E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, igual ], ECcs, ECes),
		comprueba(igualdad,E1tipos,EC2tipos,ECtipos)}.	
		
		
exp(Etsh, Eeh, Etipos, Ees, Ecs) --> termino(Etsh, Eeh, Etipos, Ees, Ecs).

exp(Etsh, Eeh, Etipos, Ees, Ecs) -->
		termino(Etsh, Eeh, T1tipos, T1es, T1cs),
		[+],
		exp(Etsh, T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, suma], Ecs, Ees),
		comprueba(suma,T1tipos, E2tipos, Etipos)}. 
exp(Etsh, Eeh, Etipos, Ees, Ecs) -->
		termino(Etsh, Eeh, T1tipos, T1es, T1cs),
		[-],
		exp(Etsh, T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, resta], Ecs, Ees),
		comprueba(suma,T1tipos, E2tipos, Etipos)}. 
		
exp(Etsh, Eeh, Etipos, Ees, Ecs) -->
		termino(Etsh, Eeh, T1tipos, T1es, T1cs),
		[or],
		exp(Etsh, T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, or], Ecs, Ees),
		comprueba(and,T1tipos, E2tipos, Etipos)}. 
	
		
termino(Ttsh, Teh, Ttipos, Tes, Tcs)--> factor(Ttsh, Teh, Ttipos, Tes, Tcs).

termino(Ttsh, Teh, Ttipos, Tes, Tcs) -->
	factor(Ttsh, Teh, Ftipos, Fes, Fcs),
	[*],
	termino(Ttsh, Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,multiplica],Tcs,Tes),
	comprueba(suma,Ftipos,T2tipos,Ttipos)}.

termino(Ttsh, Teh, Ttipos, Tes, Tcs) -->
	factor(Ttsh, Teh, Ftipos, Fes, Fcs),
	[/],
	termino(Ttsh, Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,divide],Tcs,Tes),
	comprueba(division,Ftipos,T2tipos,Ttipos)}.
termino(Ttsh, Teh, Ttipos, Tes, Tcs) -->
	factor(Ttsh, Teh, Ftipos, Fes, Fcs),
	[and],
	termino(Ttsh, Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,and],Tcs,Tes),
	comprueba(and,Ftipos,T2tipos,Ttipos)}.	
	
factor(_, Feh, Ftipos, Fes, Fcs) -->
	simbolo(V, Ftipos),
	{emite([],Feh,[Feh, apila, V],Fcs, Fes)}.
	
factor(Ftsh, Feh, Idtipo, Fes, Fcs) --> 
		id(X), 
		{buscar(Ftsh, X, Iddir, Idtipo),
		emite([],Feh,[Feh, apila-dir, Iddir],Fcs,Fes)}. 

factor(Ftsh, Feh, ECtipos, ECes, ECcs) --> 
		['('], 
		expComp(Ftsh,Feh, ECtipos, ECes, ECcs), 
		[')']. 
	

		
simbolo(V, entero) --> 
		[V], {integer(V)}. 
		
simbolo(V, real) -->
		[V], {float(V)}. 

simbolo(true, bool) -->
		[true].

simbolo(false,bool) -->
		[false].
		
	
%% A. sint�ctico y m�todos auxiliares
	
comprobar(bloque, error, _, error).
comprobar(bloque, _, error, error).
comprobar(bloque,ok,ok,ok).

	 
comprueba(asignacion, T, T, ok).
comprueba(asignacion, real, entero, ok).

comprueba(relacional, entero, entero, bool) :- !.
comprueba(relacional, entero, real, bool) :- !.
comprueba(relacional, real, entero, bool) :- !.
comprueba(relacional, real, real, bool) :- !.

comprueba(igualdad, entero, entero, bool) :- !.
comprueba(igualdad, entero, real, bool) :- !.
comprueba(igualdad, real, entero, bool) :- !.
comprueba(igualdad, real, real, bool) :- !.
comprueba(igualdad, bool, bool, bool) :- !.

comprueba(suma, entero, entero, entero) :- !.
comprueba(suma, entero, real, real) :- !.
comprueba(suma, real, entero, real) :- !.
comprueba(suma, real, real, real) :- !.

comprueba(and, bool, bool, bool) :- !.

comprueba(division, entero, entero,real) :- !.
comprueba(division, entero, real, real) :- !.
comprueba(division, real, entero, real) :- !.
comprueba(division, real, real,real) :- !.


id(X) -->
	[X], {atom(X)}.

a�adir([], Dir, _, _, Ts, Dir, Ts).

a�adir([X | L], Dir, Size, Tipo, Ts, Rdirs, Rtss):-
	Rdir is Dir + Size,
	noExiste(X, Ts),
	a�adir(L, Rdir, Size, Tipo, [[X, Tipo, Dir] | Ts], Rdirs, Rtss).


noExiste(X,[[X , _ , _] |_]):-!,write(X), write(' ya se declar�'), fail.

noExiste(X, [_ | R]):-
	noExiste(X, R).

noExiste(_, []).



concatena(L1,L2,L3) :- append(L1,L2,L3).
emite(Ch,Eh,I,Cs,Es) :- append(Ch,[I],Cs), Es is Eh + 1.
 
buscar([[X, Idtipo, Iddir] | _], X, Iddir, Idtipo):-!. 

buscar([], _, -1, error):-!. 

buscar([_ | Resto], X, Iddir, Idtipo):- 
		buscar(Resto, X, Iddir, Idtipo). 
		

% Muestra una lista de listas
mostrar([]):- nl.
mostrar([A|As]) :- nl, muestra(A), mostrar(As).
% Muestra una lista.
muestra([]).
muestra([A|As]) :- write(A), write(' '), muestra(As).