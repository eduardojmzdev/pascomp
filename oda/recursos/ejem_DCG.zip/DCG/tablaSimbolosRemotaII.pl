:- dynamic(entrada/3).

% entrada(id, tipo, dir).


programa(Ts,C) -->
  {creaTablaSimbolos},
  [begin],
  declaraciones,
  bloque([],0,ok,C,_,ok),
  [end],
  {tablaSimbolos(Ts)}.

tablaSimbolos([entrada(A,B,C)|R]) :- entrada(A,B,C), retract(entrada(A,B,C)), !, tablaSimbolos(R), assert(entrada(A,B,C)).
tablaSimbolos([]):- !.


creaTablaSimbolos :-
  retractall(entrada(_,_,_)),
  assert(entrada(var,none,none)),
  assert(entrada(finVar,none,none)),
  assert(entrada(begin,none,none)),
  assert(entrada(end,none,none)),
  assert(entrada(if,none,none)),
  assert(entrada(while,none,none)),
  assert(entrada(then,none,none)),
  assert(entrada(do,none,none)).



a�adir([],Dir,_,_,Dir).
a�adir([X|L],Dir,TTam,Tipo,Dirs) :-
	Rdir is Dir + TTam,
	\+ entrada(X,_,_),
	assert(entrada(X,Tipo,Dir)),
	a�adir(L,Rdir,TTam,Tipo,Dirs).
	
	
%% Tabla de s�mbolos.
declaraciones -->
	[var],
	lista(1),
	[finVar].

lista(Dirh) -->
	listaIds(Lids),
	[:],
	tipo(Ttipo, Ttam),
	[;],
	{a�adir(Lids, Dirh, Ttam, Ttipo, Dirs)},
	lista(Dirs).

lista(_) --> [].

listaIds([ X | Ls]) -->
	id(X),
	[,],
	listaIds(Ls).

listaIds([X]) -->
	id(X).

tipo(real, 2) --> [real].
tipo(entero, 1) --> [entero].
tipo(bool,1) --> [bool].


%% Instrucciones

bloque(Ich, Ieh, Itipoh, Ics, Ies, Itipos) -->
      ['{'],
      instrucciones(Ich, Ieh, Itipoh, Ics, Ies, Itipos),
      ['}'].
   
      
inst(Ich, Ieh, _, Ics, Ies, Itipos) -->
		id(X),
		{entrada(X,Idtipo,Iddir)},
		[:=],
		{emite(Ich,Ieh,[Ieh, apila, Iddir], C1, ECeh)},
		expComp(ECeh,ECtipos,ECes,ECcs),
		{concatena(C1,ECcs,C2),
		 emite(C2,ECes,[ECes, desapila-ind], Ics, Ies),
		 comprueba(asignacion,Idtipo,ECtipos,Itipos)}.
		 
inst(Ich, Ieh, _, Ics, Ies, Itipos) -->
		[while],
		['('],
		expComp(Ieh,ECtipos,ECes,ECcs),
		[')'],
		[do],
		{ ECtipos == bool,
		  concatena(Ich,ECcs,Aux),
		  emite(Aux,ECes,[ECes,ir-falso,Ies],I2ch,I2eh) },
		bloque(I2ch,I2eh,_,I2cs,I2es,Itipos),
		{ emite(I2cs,I2es,[I2es,ir-siempre,Ieh],Ics,Ies)}.
		
inst(Ich, Ieh, _, Ics, Ies, Itipos) -->
		[if],
		['('],
		expComp(Ieh,ECtipos,ECes,ECcs),
		[')'],
		[then],
		{ ECtipos == bool,
		  concatena(Ich,ECcs,Aux),
		  emite(Aux,ECes,[ECes,ir-falso,Bes],I2ch,I2eh) },
		bloque(I2ch,I2eh,_,Bcs,Bes,Btipos),
		[else],
		{emite(Bcs,Bes,[Bes, ir-siempre, Ies], I3ch, I3eh)},
		bloque(I3ch,I3eh,Btipos,Ics,Ies,Itipos).
	

instrucciones(ISch, ISeh, IStipoh, IScs, ISes, IStipos) -->
	inst(ISch, ISeh, IStipoh, Ics, Ies, Itipos),
	restoIns(Ics, Ies, Itipos, IScs, ISes, RItipos),
	{comprobar(bloque,Itipos,RItipos,IStipos)}.

	
restoIns(ISch, ISeh, IStipoh, ISch, ISeh, IStipoh) --> [;].

restoIns(Ich, Ieh, Itipoh, Ics, Ies, Itipos) -->
   [;],
   instrucciones(Ich, Ieh, Itipoh, Ics, Ies, Itipos).


%% Expresiones


expComp(ECeh, ECtipos, ECes, ECcs) -->
		exp(ECeh, ECtipos, ECes, ECcs).
		
expComp(ECeh, ECtipos, ECes, ECcs) -->
		exp(ECeh, E1tipos, E1es, E1cs),
		[<],
		expComp(E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, menor ], ECcs, ECes),
		comprueba(relacional,E1tipos,EC2tipos,ECtipos)}.
expComp(ECeh, ECtipos, ECes, ECcs) -->
		exp(ECeh, E1tipos, E1es, E1cs),
		[>],
		expComp(E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, mayor ], ECcs, ECes),
		comprueba(relacional,E1tipos,EC2tipos,ECtipos)}.
expComp(ECeh, ECtipos, ECes, ECcs) -->
		exp( ECeh, E1tipos, E1es, E1cs),
		[=],
		expComp(E1es, EC2tipos, EC2es, EC2cs),
		{concatena(E1cs, EC2cs, Aux),
		emite(Aux, EC2es, [EC2es, igual ], ECcs, ECes),
		comprueba(igualdad,E1tipos,EC2tipos,ECtipos)}.	
		
		
exp(Eeh, Etipos, Ees, Ecs) --> termino(Eeh, Etipos, Ees, Ecs).

exp(Eeh, Etipos, Ees, Ecs) -->
		termino(Eeh, T1tipos, T1es, T1cs),
		[+],
		exp(T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, suma], Ecs, Ees),
		comprueba(suma,T1tipos, E2tipos, Etipos)}. 
exp( Eeh, Etipos, Ees, Ecs) -->
		termino(Eeh, T1tipos, T1es, T1cs),
		[-],
		exp(T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, resta], Ecs, Ees),
		comprueba(suma,T1tipos, E2tipos, Etipos)}. 
		
exp(Eeh, Etipos, Ees, Ecs) -->
		termino(Eeh, T1tipos, T1es, T1cs),
		[or],
		exp(T1es, E2tipos, E2es, E2cs),
		{concatena(T1cs, E2cs, Aux),
		emite(Aux, E2es, [E2es, or], Ecs, Ees),
		comprueba(and,T1tipos, E2tipos, Etipos)}. 
	
		
termino(Teh, Ttipos, Tes, Tcs)--> factor( Teh, Ttipos, Tes, Tcs).

termino(Teh, Ttipos, Tes, Tcs) -->
	factor(Teh, Ftipos, Fes, Fcs),
	[*],
	termino(Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,multiplica],Tcs,Tes),
	comprueba(suma,Ftipos,T2tipos,Ttipos)}.

termino(Teh, Ttipos, Tes, Tcs) -->
	factor(Teh, Ftipos, Fes, Fcs),
	[/],
	termino(Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,divide],Tcs,Tes),
	comprueba(division,Ftipos,T2tipos,Ttipos)}.
termino(Teh, Ttipos, Tes, Tcs) -->
	factor(Teh, Ftipos, Fes, Fcs),
	[and],
	termino(Fes, T2tipos, T2es, T2cs),
	{concatena(Fcs,T2cs,Aux),
	emite(Aux,T2es,[T2es,and],Tcs,Tes),
	comprueba(and,Ftipos,T2tipos,Ttipos)}.	
	
factor(Feh, Ftipos, Fes, Fcs) -->
	simbolo(V, Ftipos),
	{emite([],Feh,[Feh, apila, V],Fcs, Fes)}.
	
factor(Feh, Idtipo, Fes, Fcs) --> 
		id(X), 
		{entrada(X, Idtipo, Iddir),
		emite([],Feh,[Feh, apila-dir, Iddir],Fcs,Fes)}. 

factor(Feh, ECtipos, ECes, ECcs) --> 
		['('], 
		expComp(Feh, ECtipos, ECes, ECcs), 
		[')']. 
	

		
simbolo(V, entero) --> 
		[V], {integer(V)}. 
		
simbolo(V, real) -->
		[V], {float(V)}. 

simbolo(true, bool) -->
		[true].

simbolo(false,bool) -->
		[false].
		
	
	
%% A. sint�ctico y m�todos auxiliares
	
comprobar(bloque, error, _, error).
comprobar(bloque, _, error, error).
comprobar(bloque,ok,ok,ok).

	 
comprueba(asignacion, T, T, ok).
comprueba(asignacion, real, entero, ok).

comprueba(relacional, entero, entero, bool) :- !.
comprueba(relacional, entero, real, bool) :- !.
comprueba(relacional, real, entero, bool) :- !.
comprueba(relacional, real, real, bool) :- !.

comprueba(igualdad, entero, entero, bool) :- !.
comprueba(igualdad, entero, real, bool) :- !.
comprueba(igualdad, real, entero, bool) :- !.
comprueba(igualdad, real, real, bool) :- !.
comprueba(igualdad, bool, bool, bool) :- !.

comprueba(suma, entero, entero, entero) :- !.
comprueba(suma, entero, real, real) :- !.
comprueba(suma, real, entero, real) :- !.
comprueba(suma, real, real, real) :- !.

comprueba(and, bool, bool, bool) :- !.

comprueba(division, entero, entero,real) :- !.
comprueba(division, entero, real, real) :- !.
comprueba(division, real, entero, real) :- !.
comprueba(division, real, real,real) :- !.


id(X) -->
	[X], {atom(X)}.







concatena(L1,L2,L3) :- append(L1,L2,L3).
emite(Ch,Eh,I,Cs,Es) :- append(Ch,[I],Cs), Es is Eh + 1.
 
 
		

% Muestra una lista de listas
mostrar([]):- nl.
mostrar([A|As]) :- nl, muestra(A), mostrar(As).
% Muestra una lista.
muestra([]).
muestra([A|As]) :- write(A), write(' '), muestra(As).
% Muestra una entrada.
muestra(entrada(A,B,C)) :- write(entrada(A,B,C)).


% declaraciones([var,a,:,bool,;,finVar],S), tablaSimbolos(Ts), mostrar(Ts), bloque([],1,_,C,E,T,['{',if,'(',true,')',then,'{',while,'(',a,')',do,'{',a,:=,false,;,'}',;,'}',;,'}'],[]).

% programa(Ts,C, [begin,var,a,:,bool,;,finVar,'{',if,'(',true,')',then,'{',while,'(',a,')',do,'{',a,:=,false,;,'}',;,'}',;,'}',end],[]), mostrar(Ts), mostrar(C).

% creaTablaSimbolos, declaraciones([var,a,:,bool,;,finVar],S), tablaSimbolos(Ts), mostrar(Ts), bloque([],1,_,C,E,T,['{',if,'(',true,')',then,'{',while,'(',a,')',do,'{',a,:=,false,;,'}',;,'}',;,'}'],[]), mostrar(C).